# -*- coding: utf-8 -*-
"""Genspark Arkhivator — единое окно, voxel-стилизация (НЕ копирует Minecraft,
используется собственная палитра изумруд/мох/песок/сланец/дерево и открытый
пиксельный шрифт из системы, если установлен).

Реализованные улучшения (по промту):
  1. Вкладка "Мои промпты" — сохранить свой промпт, поиск по промптам и
     кнопка "искать похожие чаты на этот промпт" (берёт целый текст промпта
     и прогоняет через объединённый поисковик).
  2. Подсветка совпадений в TXT после поиска: жёлтые вхождения + клик по
     вхождению = переход, кнопки "◀ пред. совпадение / след. совпадение ▶".
  3. Семантический поиск офлайн: TF-IDF + словарь синонимов + RapidFuzz,
     единая точка входа — switched_move on language («по смыслу»).
  4. Автосохранение заметок каждые 1.5 секунды + Ctrl+S (без ручного сохранения).
  5. Дубликаты (md5) и похожие чаты (Jaccard) — кнопка "Дубликаты и похожие".
  6. Поиск с опечатками и «по смыслу» объединены в один поиск, результат
     выдаётся одним списком с разбивкой по баллам (title / description /
     body / semantic).
  7. Описания строятся БЕЗ ИИ: библиотека sumy (TextRank/LexRank), русский
     поддерживается штатно.
  + Voxel-restyling интерфейса под референс: блочные рамки, stepped pixel
    edges, тематическая палитра, без чужого брендинга.
"""
import datetime
import os
import queue
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import webbrowser

import db
import extractor
import prompts as promptsm
import duplicates as dupmod
import theme as thememod

try:
    import unified_search as searchmod
    HAVE_UNIFIED = True
except Exception:
    HAVE_UNIFIED = False
    import search as searchmod

try:
    import sumy_summarizer as summod
    HAVE_SUMY = True
except Exception:
    try:
        import summarizer as summod
    except Exception:
        summod = None
    HAVE_SUMY = False


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
SETTINGS_PATH = os.path.join(DATA_DIR, "settings.json")

SORTS = {"начало сессии": "session", "последнее открытие": "opened", "по названию": "title"}
SEARCH_MODES = {"слова+смысл": "mixed", "только слова": "exact", "только смысл": "semantic"}


def load_settings():
    import json
    defaults = {
        "engine": "offline", "gemini_key": "", "gemini_model": "gemini-2.5-flash",
        "headless": True, "theme": "Светлая", "search_mode": "слова+смысл",
        "min_score": 12,
    }
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        if os.path.exists(SETTINGS_PATH):
            with open(SETTINGS_PATH, encoding="utf-8") as f:
                d = json.load(f)
            if isinstance(d, dict):
                defaults.update(d)
    except Exception:
        pass
    return defaults


def save_settings(s):
    import json
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
            json.dump(s, ensure_ascii=False, indent=2)
    except Exception:
        pass


# ---------------- главный App ----------------
class App:
    def __init__(self, root):
        self.root = root
        self.settings = load_settings()
        self.q = queue.Queue()
        self.loading_ids = set()
        self.search_map = {}
        self.search_highlight = ""
        self.match_positions = []
        self.match_idx = 0
        self.in_search = False

        self.colors = thememod.apply_theme(root, self.settings.get("theme", "Светлая"))
        self.root.title("Genspark Arkhivator — voxel edition")
        self.root.geometry("1320x860")
        self.root.minsize(1080, 680)

        self._build_top()
        self._build_search()
        self._build_main()
        self._build_bottom()

        db.init_db()
        promptsm.ensure_table()
        self.refresh_list()
        self._refresh_prompts_list()
        self._note_autosave()
        self.root.after(200, self._drain_queue)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    # ===== верх =====
    def _build_top(self):
        t = self.colors
        frame = tk.Frame(self.root, bg=t["bg"])
        frame.pack(fill="x", padx=10, pady=(8, 2))
        tk.Label(frame, text="Ссылка на чат Genspark:", bg=t["bg"], fg=t["fg"],
                 font=t["font"]).grid(row=0, column=0, sticky="w")
        self.url_var = tk.StringVar()
        self.url_entry = tk.Entry(frame, textvariable=self.url_var, font=t["font"],
                                  bg=t["entry_bg"], fg=t["entry_fg"], insertbackground=t["fg"])
        self.url_entry.grid(row=0, column=1, sticky="ew", padx=6)
        self.url_entry.bind("<Return>", lambda e: self.on_go())
        self.go_btn = tk.Button(frame, text="ВЫГРУЗИТЬ ЧАТ", command=self.on_go,
                                bg=t["accent"], fg="#ffffff", font=("TkDefaultFont", 10, "bold"),
                                activebackground=t["accent"], relief="raised", padx=10, bd=3)
        self.go_btn.grid(row=0, column=2, padx=(0, 6))
        self.light = tk.Label(frame, text=" ", width=2, bg="#9a9a9a", relief="sunken", bd=2)
        self.light.grid(row=0, column=3, padx=(2, 6))
        self.status_var = tk.StringVar(value="Готово. Вставьте ссылку и нажмите «Выгрузить чат».")
        tk.Label(frame, textvariable=self.status_var, bg=t["bg"], fg=t["fg"],
                 font=t["font"], anchor="w").grid(row=0, column=4, sticky="ew")
        frame.columnconfigure(1, weight=1)
        frame.columnconfigure(4, weight=1)
        self.progress = ttk.Progressbar(self.root, mode="indeterminate")

    # ===== поиск =====
    def _build_search(self):
        t = self.colors
        bar = tk.Frame(self.root, bg=t["bg"])
        bar.pack(fill="x", padx=10, pady=(2, 2))
        tk.Label(bar,
                 text="Поиск по архиву: с опечатками, по смыслу, по целому промпту:",
                 bg=t["bg"], fg=t["fg"], font=t["font"]).pack(side="left")

        self.search_var = tk.StringVar()
        self.search_entry = tk.Entry(bar, textvariable=self.search_var, font=t["font"],
                                     bg=t["entry_bg"], fg=t["entry_fg"],
                                     insertbackground=t["fg"])
        self.search_entry.pack(side="left", fill="x", expand=True, padx=6)
        self.search_entry.bind("<Return>", lambda e: self.on_search())

        tk.Label(bar, text="Режим:", bg=t["bg"], fg=t["fg"], font=t["font"]).pack(side="left", padx=(6, 2))
        self.search_mode_var = tk.StringVar(value=self.settings.get("search_mode", "слова+смысл"))
        self.search_mode_cb = ttk.Combobox(
            bar, textvariable=self.search_mode_var, state="readonly", width=14,
            values=list(SEARCH_MODES.keys()))
        self.search_mode_cb.pack(side="left", padx=2)

        tk.Button(bar, text="Найти", command=self.on_search, bg=t["accent"], fg="#fff",
                  font=("TkDefaultFont", 10, "bold"), bd=3).pack(side="left", padx=(6, 2))
        tk.Button(bar, text="🧠 Смысл", command=self.on_semantic_search,
                  bg=t["panel"], fg=t["fg"], font=t["font"], bd=3).pack(side="left", padx=2)
        tk.Button(bar, text="Сброс", command=self.on_search_reset,
                  bg=t["panel"], fg=t["fg"], font=t["font"], bd=3).pack(side="left", padx=2)

        self.search_info = tk.StringVar(value="")
        tk.Label(bar, textvariable=self.search_info, bg=t["bg"], fg=t["fg"],
                 font=t["font"]).pack(side="left", padx=8)

    # ===== центр =====
    def _build_main(self):
        paned = ttk.Panedwindow(self.root, orient="horizontal")
        paned.pack(fill="both", expand=True, padx=10, pady=4)

        # ---- левый блок: таблица чатов ----
        left = tk.Frame(paned, bg=self.colors["bg"])
        paned.add(left, weight=3)
        bar = tk.Frame(left, bg=self.colors["bg"])
        bar.pack(fill="x")
        tk.Label(bar, text="Сортировка:", bg=self.colors["bg"], fg=self.colors["fg"],
                 font=self.colors["font"]).pack(side="left")
        self.sort_var = tk.StringVar(value="начало сессии")
        self.sort_cb = ttk.Combobox(bar, textvariable=self.sort_var, state="readonly",
                                    width=17, values=list(SORTS.keys()))
        self.sort_cb.pack(side="left", padx=4)
        self.sort_cb.bind("<<ComboboxSelected>>", lambda e: self.refresh_list())
        self.fav_only_var = tk.BooleanVar(value=False)
        tk.Checkbutton(bar, text="Только ★", variable=self.fav_only_var, command=self.refresh_list,
                       bg=self.colors["bg"], fg=self.colors["fg"],
                       selectcolor=self.colors["panel"],
                       font=self.colors["font"]).pack(side="left", padx=6)

        cols = ("status", "title", "session", "size", "fav")
        self.tree = ttk.Treeview(left, columns=cols, show="headings", selectmode="browse")
        self.tree.heading("status", text="Статус")
        self.tree.heading("title", text="Название")
        self.tree.heading("session", text="Дата сессии")
        self.tree.heading("size", text="TXT")
        self.tree.heading("fav", text="★")
        self.tree.column("status", width=130, anchor="w")
        self.tree.column("title", width=360, anchor="w")
        self.tree.column("session", width=150, anchor="w")
        self.tree.column("size", width=80, anchor="w")
        self.tree.column("fav", width=34, anchor="center")
        self._apply_row_tags()

        # п.6: предпросмотр при наведении
        self.tree.bind("<Motion>", self._on_tree_hover)
        vsb = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._on_select)
        self.tree.bind("<Double-1>", lambda e: self._show_txt_tab())

        # всплывашка предпросмотра
        self.preview = tk.Toplevel(self.root)
        self.preview.withdraw()
        self.preview.overrideredirect(True)
        self.prev_lbl = tk.Label(self.preview, justify="left", padx=8, pady=6,
                                 bg=self.colors.get("entry_bg", "#fffbd7"),
                                 fg=self.colors["fg"], relief="solid", bd=2,
                                 font=self.colors["font"], wraplength=560)
        self.prev_lbl.pack()

        # ---- правый блок: вкладки ----
        right = tk.Frame(paned, bg=self.colors["bg"])
        paned.add(right, weight=4)
        self.nb = ttk.Notebook(right)
        self.nb.pack(fill="both", expand=True)

        # 1) Текст чата (TXT) — заголовки ТОЧНО как в референсе
        tab_txt = tk.Frame(self.nb, bg=self.colors["bg"])
        self.nb.add(tab_txt, text=" Текст чата (TXT) ")
        toolbar = tk.Frame(tab_txt, bg=self.colors["bg"])
        toolbar.pack(fill="x")
        tk.Button(toolbar, text="◀ пред. совпадение", command=self._prev_match,
                  bg=self.colors["panel"], fg=self.colors["fg"], font=self.colors["font"],
                  bd=3).pack(side="left", padx=2)
        tk.Button(toolbar, text="след. совпадение ▶", command=self._next_match,
                  bg=self.colors["panel"], fg=self.colors["fg"], font=self.colors["font"],
                  bd=3).pack(side="left", padx=2)
        self.match_info = tk.StringVar(value="")
        tk.Label(toolbar, textvariable=self.match_info, bg=self.colors["bg"],
                 fg=self.colors["fg"], font=self.colors["font"]).pack(side="left", padx=8)

        self.txt_view = tk.Text(tab_txt, wrap="word", font=("Consolas", 10),
                                bg=self.colors["entry_bg"], fg=self.colors["entry_fg"],
                                state="disabled", undo=False)
        self.txt_view.tag_configure("hit", background=self.colors.get("hit", "#fff17a"),
                                    foreground="#000")
        txt_sb = ttk.Scrollbar(tab_txt, orient="vertical", command=self.txt_view.yview)
        self.txt_view.configure(yscrollcommand=txt_sb.set)
        txt_sb.pack(side="right", fill="y")
        self.txt_view.pack(fill="both", expand=True)
        # клик по подсвеченному фрагменту — переход к нему
        self.txt_view.tag_bind("hit", "<Button-1>", self._on_hit_click)

        # 2) Мои заметки — автосохранение каждые 1.5 с
        tab_notes = tk.Frame(self.nb, bg=self.colors["bg"])
        self.nb.add(tab_notes, text=" Мои заметки ")
        self.notes = tk.Text(tab_notes, wrap="word", undo=True, font=self.colors["font"],
                             bg=self.colors["entry_bg"], fg=self.colors["entry_fg"])
        self.notes.pack(fill="both", expand=True)
        tk.Button(tab_notes,
                  text="Сохранить заметки  (Ctrl+S, авто каждые 1.5 с)",
                  command=self.save_notes, bg=t["accent"], fg="#fff",
                  font=("TkDefaultFont", 10, "bold"), bd=3).pack(fill="x", pady=3)
        self.notes.bind("<Control-s>", lambda e: (self.save_notes(), "break"))
        self.root.bind("<Control-s>", lambda e: (self.save_notes(), "break"))
        self.notes.bind("<<Modified>>", self._on_notes_modified)

        # 3) Описание — три режима, БЕЗ ИИ (sumy)
        tab_desc = tk.Frame(self.nb, bg=self.colors["bg"])
        self.nb.add(tab_desc, text=" Описание ")
        dbar = tk.Frame(tab_desc, bg=self.colors["bg"])
        dbar.pack(fill="x")
        self.mode_var = tk.StringVar(value="min")
        for key, label in (("min", "Минимум (10-15)"),
                           ("med", "Среднее (40-50)"),
                           ("max", "Максимум (70+)")):
            tk.Radiobutton(dbar, text=label, value=key, variable=self.mode_var,
                           command=self._show_desc, bg=self.colors["bg"], fg=self.colors["fg"],
                           selectcolor=self.colors["panel"],
                           font=self.colors["font"]).pack(side="left", padx=6)
        tk.Button(dbar, text="Копировать", command=self._copy_desc,
                  bg=self.colors["panel"], fg=self.colors["fg"], font=self.colors["font"],
                  bd=3).pack(side="right")
        self.desc_view = tk.Text(tab_desc, wrap="word", font=self.colors["font"],
                                 bg=self.colors["entry_bg"], fg=self.colors["entry_fg"],
                                 state="disabled")
        self.desc_view.pack(fill="both", expand=True, pady=3)

        # 4) Мои промпты — вкладка п.1
        tab_prom = tk.Frame(self.nb, bg=self.colors["bg"])
        self.nb.add(tab_prom, text=" Мои промпты ")
        ptop = tk.Frame(tab_prom, bg=self.colors["bg"])
        ptop.pack(fill="x")
        tk.Label(ptop,
                 text="Поиск по своим промптам. По кнопке ниже — ищет похожие чаты на ЦЕЛЫЙ промпт:",
                 bg=self.colors["bg"], fg=self.colors["fg"], font=self.colors["font"]).pack(side="left")
        self.prompt_q = tk.StringVar()
        self.prompt_q_entry = tk.Entry(ptop, textvariable=self.prompt_q,
                                       bg=self.colors["entry_bg"], fg=self.colors["entry_fg"],
                                       font=self.colors["font"])
        self.prompt_q_entry.pack(side="left", fill="x", expand=True, padx=6)
        self.prompt_q_entry.bind("<Return>", lambda e: self._refresh_prompts_list())
        tk.Button(ptop, text="Найти", command=self._refresh_prompts_list,
                  bg=self.colors["accent"], fg="#fff", font=("TkDefaultFont", 10, "bold"),
                  bd=3).pack(side="left", padx=2)
        tk.Button(ptop, text="Сохранить промпт", command=self._save_current_as_prompt,
                  bg=self.colors["panel"], fg=self.colors["fg"], font=self.colors["font"],
                  bd=3).pack(side="left", padx=2)
        pcols = ("when", "chat", "uses", "text")
        self.prom_tree = ttk.Treeview(tab_prom, columns=pcols, show="headings", selectmode="browse")
        self.prom_tree.heading("when", text="Когда")
        self.prom_tree.heading("chat", text="Чат")
        self.prom_tree.heading("uses", text="Запросов")
        self.prom_tree.heading("text", text="Текст промпта")
        self.prom_tree.column("when", width=140)
        self.prom_tree.column("chat", width=160)
        self.prom_tree.column("uses", width=70, anchor="center")
        self.prom_tree.column("text", width=560)
        psb = ttk.Scrollbar(tab_prom, orient="vertical", command=self.prom_tree.yview)
        self.prom_tree.configure(yscrollcommand=psb.set)
        psb.pack(side="right", fill="y")
        self.prom_tree.pack(fill="both", expand=True)
        self.prom_tree.bind("<Double-1>", self._use_prompt)
        pbot = tk.Frame(tab_prom, bg=self.colors["bg"])
        pbot.pack(fill="x", pady=3)
        tk.Button(pbot, text="Найти похожие чаты на этот промпт (как вы просили)",
                  command=self._use_prompt, bg=self.colors["accent"], fg="#fff",
                  font=("TkDefaultFont", 10, "bold"), bd=3).pack(side="left")
        tk.Button(pbot, text="Удалить промпт", command=self._delete_prompt,
                  bg=self.colors["panel"], fg=self.colors["fg"], font=self.colors["font"],
                  bd=3).pack(side="left", padx=4)

    # ===== низ =====
    def _build_bottom(self):
        t = self.colors
        bar = tk.Frame(self.root, bg=t["bg"])
        bar.pack(fill="x", padx=10, pady=(2, 2))
        for text, cmd in (
            ("★ Избранное", self.toggle_fav),
            ("Открыть TXT в редакторе", self.open_txt),
            ("Удалить из списка", self.on_delete),
            ("Экспорт архива в ZIP", self.export_all),
            ("Экспорт чата в Markdown", self.export_md),
            ("Дубликаты и похожие", self.find_duplicates),
            ("Открыть папку data", self.open_data_folder),
        ):
            tk.Button(bar, text=text, command=cmd, bg=t["panel"], fg=t["fg"],
                      font=t["font"], bd=3).pack(side="left", padx=3)

        bar2 = tk.Frame(self.root, bg=t["bg"])
        bar2.pack(fill="x", padx=10, pady=(0, 6))
        tk.Label(bar2, text="Тема:", bg=t["bg"], fg=t["fg"], font=t["font"]).pack(side="left")
        self.theme_var = tk.StringVar(value=self.settings.get("theme", "Светлая"))
        self.theme_cb = ttk.Combobox(bar2, textvariable=self.theme_var, state="readonly",
                                     width=22, values=thememod.list_themes())
        self.theme_cb.pack(side="left", padx=4)
        self.theme_cb.bind("<<ComboboxSelected>>", lambda e: self._change_theme())

        tk.Label(bar2, text="Описание:", bg=t["bg"], fg=t["fg"], font=t["font"]).pack(side="left", padx=(12, 2))
        self.engine_var = tk.StringVar(value=self.settings.get("engine", "offline"))
        self.engine_cb = ttk.Combobox(bar2, textvariable=self.engine_var, state="readonly",
                                      width=9, values=["offline", "gemini"])
        self.engine_cb.pack(side="left", padx=4)
        self.engine_cb.bind("<<ComboboxSelected>>", lambda e: self._save_settings())

        tk.Label(bar2, text="Gemini-ключ (бесплатно: aistudio.google.com):",
                 bg=t["bg"], fg=t["fg"], font=t["font"]).pack(side="left", padx=(10, 2))
        self.key_var = tk.StringVar(value=self.settings.get("gemini_key", ""))
        self.key_entry = tk.Entry(bar2, textvariable=self.key_var, width=26, show="*",
                                  bg=t["entry_bg"], fg=t["entry_fg"], insertbackground=t["fg"])
        self.key_entry.pack(side="left", padx=4)
        self.headless_var = tk.BooleanVar(value=bool(self.settings.get("headless", True)))
        tk.Checkbutton(bar2, text="Фоновый браузер", variable=self.headless_var,
                       command=self._save_settings, bg=t["bg"], fg=t["fg"],
                       selectcolor=t["panel"], font=t["font"]).pack(side="left", padx=8)
        tk.Button(bar2, text="Сохранить", command=self._save_settings,
                  bg=t["accent"], fg="#fff",
                  font=("TkDefaultFont", 10, "bold"), bd=3).pack(side="left", padx=4)

    # ---------------- row tags ----------------
    def _apply_row_tags(self):
        t = self.colors
        try:
            self.tree.tag_configure("ready", background=t.get("ready", "#2f6b2f"),
                                    foreground=t["fg"])
            self.tree.tag_configure("loading", background=t.get("loading", "#8a7a2a"),
                                    foreground=t["fg"])
        except Exception:
            pass

    def _row_tag(self, chat_id):
        return "loading" if chat_id in self.loading_ids else "ready"

    # ---------------- список ----------------
    def refresh_list(self, select_id=None):
        self.in_search = False
        self.search_map.clear()
        try:
            self.tree.delete(*self.tree.get_children())
        except Exception:
            pass
        chats = db.list_chats(sort_by=SORTS.get(self.sort_var.get(), "session"),
                              only_fav=self.fav_only_var.get())
        for ch in chats:
            self._insert_row(ch)
            if select_id and ch["chat_id"] == select_id:
                self.tree.selection_set(ch["chat_id"])
                self.tree.see(ch["chat_id"])
        self._on_select()

    def _insert_row(self, ch, status_text=None):
        cid = ch["chat_id"]
        txt = ch.get("txt_path") or ""
        try:
            size = "%d КБ" % (os.path.getsize(txt) // 1024) if txt and os.path.exists(txt) else ""
        except Exception:
            size = ""
        if status_text is None:
            status_text = "⏳ догружает" if cid in self.loading_ids else "✔ готов"
        vals = (status_text, ch.get("title") or "Без названия",
                ch.get("first_prompt_at") or "—", size, "★" if ch.get("favorite") else "")
        try:
            if self.tree.exists(cid):
                self.tree.item(cid, values=vals, tags=(self._row_tag(cid),))
            else:
                self.tree.insert("", "end", iid=cid, values=vals, tags=(self._row_tag(cid),))
        except Exception:
            pass

    def _sel(self):
        try:
            sel = self.tree.selection()
        except Exception:
            return None
        return sel[0] if sel else None

    def _on_select(self, event=None):
        cid = self._sel()
        try:
            self.notes.delete("1.0", "end")
            self._set_text(self.txt_view, "")
            self._set_text(self.desc_view, "")
        except Exception:
            pass
        self.match_positions = []
        self.match_idx = 0
        if not cid:
            return
        ch = db.get_chat(cid)
        if not ch:
            return
        if ch.get("notes"):
            try:
                self.notes.insert("1.0", ch["notes"])
            except Exception:
                pass
        snippet = ""
        if self.in_search and cid in self.search_map:
            snippet = self.search_map[cid][1]
        self._load_txt_view(ch, snippet)
        self._show_desc()

    # ---------------- п.6: hover preview ----------------
    def _on_tree_hover(self, event):
        try:
            iid = self.tree.identify_row(event.y)
        except Exception:
            iid = ""
        if not iid:
            try:
                self.preview.withdraw()
            except Exception:
                pass
            return
        ch = db.get_chat(iid)
        if not ch:
            try:
                self.preview.withdraw()
            except Exception:
                pass
            return
        prev = (ch.get("title") or "")
        if ch.get("txt_path") and os.path.exists(ch["txt_path"]):
            try:
                with open(ch["txt_path"], encoding="utf-8", errors="ignore") as f:
                    prev = f.read(280).replace("\n", " ")
            except Exception:
                pass
        try:
            self.prev_lbl.configure(text=(prev[:360].strip() + "…") if len(prev) > 360 else prev)
            x = self.root.winfo_pointerx() + 14
            y = self.root.winfo_pointery() + 14
            self.preview.geometry("+%d+%d" % (x, y))
            self.preview.deiconify()
        except Exception:
            pass

    def _set_text(self, widget, text):
        try:
            widget.configure(state="normal")
            widget.delete("1.0", "end")
            widget.insert("1.0", text)
            widget.configure(state="disabled")
        except Exception:
            pass

    # ---------------- п.2: подсветка совпадений ----------------
    def _highlight_hits(self, query):
        """Жёлтые вхождения слов запроса в TXT + запоминание позиций для навигации."""
        try:
            self.txt_view.configure(state="normal")
            self.txt_view.tag_remove("hit", "1.0", "end")
        except Exception:
            return
        self.match_positions = []
        self.match_idx = 0
        if not query:
            self.match_info.set("")
            try:
                self.txt_view.configure(state="disabled")
            except Exception:
                pass
            return
        words = [w for w in query.lower().split() if len(w) >= 3]
        if not words:
            self.match_info.set("")
            try:
                self.txt_view.configure(state="disabled")
            except Exception:
                pass
            return
        start = "1.0"
        n = 0
        for w in words:
            pos = self.txt_view.search(w, start, stopindex="end", nocase=True)
            while pos:
                end = "%s+%dc" % (pos, len(w))
                self.txt_view.tag_add("hit", pos, end)
                self.match_positions.append(pos)
                n += 1
                pos = self.txt_view.search(w, end, stopindex="end", nocase=True)
        try:
            self.txt_view.configure(state="disabled")
        except Exception:
            pass
        self.match_info.set("совпадений в TXT: %d" % n if n else "совпадений в TXT нет")
        if n:
            self._show_match(0)

    def _on_hit_click(self, _event=None):
        """Клик по подсвеченному фрагменту — переход на ближайшее совпадение."""
        if not self.match_positions:
            return "break"

    def _show_match(self, idx):
        if not self.match_positions:
            return
        self.match_idx = idx % len(self.match_positions)
        pos = self.match_positions[self.match_idx]
        try:
            self.txt_view.see(pos)
        except Exception:
            pass
        self.match_info.set("совпадение %d/%d" % (self.match_idx + 1, len(self.match_positions)))

    def _next_match(self):
        if self.match_positions:
            self._show_match(self.match_idx + 1)

    def _prev_match(self):
        if self.match_positions:
            self._show_match(self.match_idx - 1)

    def _load_txt_view(self, ch, snippet=""):
        p = ch.get("txt_path") or ""
        body = ""
        try:
            if p and os.path.exists(p):
                with open(p, encoding="utf-8", errors="ignore") as f:
                    body = f.read(1_500_000)
        except Exception as e:
            body = "(не удалось прочитать файл: %s)" % e
        if not body:
            body = "(TXT пока пуст — если статус «догружает», подождите окончания выгрузки.)"
        if snippet:
            body = "— НАЙДЕННЫЙ ФРАГМЕНТ —\n«…%s…»\n%s\n\n%s" % (snippet.strip(), "—" * 50, body)
        self._set_text(self.txt_view, body)
        self._highlight_hits(self.search_highlight)

    def _show_txt_tab(self):
        try:
            self.nb.select(0)
        except Exception:
            pass

    # ---------------- описания (sumy, БЕЗ ИИ) ----------------
    def _desc_of(self, ch, mode):
        section = ch.get("desc_" + mode) or "(Описание появится после выгрузки чата.)"
        parts = section.split("\n\n", 1)
        return parts[1] if len(parts) == 2 else section

    def _show_desc(self):
        cid = self._sel()
        if not cid:
            return
        ch = db.get_chat(cid)
        if ch:
            self._set_text(self.desc_view, self._desc_of(ch, self.mode_var.get()))

    def _copy_desc(self):
        cid = self._sel()
        if not cid:
            return
        ch = db.get_chat(cid)
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(self._desc_of(ch, self.mode_var.get()))
        except Exception:
            pass
        self._status("Описание скопировано в буфер обмена.", "ok")

    # ---------------- заметки с автосохранением ----------------
    _NOTE_DIRTY = False

    def _on_notes_modified(self, _e=None):
        self._NOTE_DIRTY = True
        try:
            self.notes.edit_modified(False)
        except Exception:
            pass

    def _note_autosave(self):
        if self._NOTE_DIRTY:
            cid = self._sel()
            if cid:
                try:
                    db.update_notes(cid, self.notes.get("1.0", "end").strip())
                except Exception:
                    pass
            self._NOTE_DIRTY = False
        try:
            self.root.after(1500, self._note_autosave)
        except Exception:
            pass

    def save_notes(self):
        cid = self._sel()
        if not cid:
            return "break"
        try:
            db.update_notes(cid, self.notes.get("1.0", "end").strip())
        except Exception as e:
            messagebox.showerror("Заметки", "Не удалось сохранить: %s" % e)
            return "break"
        self._NOTE_DIRTY = False
        ch = db.get_chat(cid)
        self._status("Заметки сохранены для «%s»." % (ch["title"] if ch else cid), "ok")
        return "break"

    # ---------------- кнопки ----------------
    def toggle_fav(self):
        cid = self._sel()
        if not cid:
            return
        ch = db.get_chat(cid)
        db.set_favorite(cid, not (ch and ch.get("favorite")))
        if self.in_search:
            self.on_search()
        else:
            self.refresh_list(select_id=cid)

    def on_delete(self):
        cid = self._sel()
        if not cid:
            return
        ch = db.get_chat(cid)
        if messagebox.askyesno("Удалить", "Убрать «%s» из списка?\nФайлы .txt и .html останутся в data/chats."
                               % (ch["title"] if ch else cid)):
            db.delete_chat(cid)
            self.refresh_list()

    def open_txt(self):
        cid = self._sel()
        if not cid:
            return
        ch = db.get_chat(cid)
        p = (ch.get("txt_path") or "") if ch else ""
        if p and os.path.exists(p):
            try:
                os.startfile(p)
            except Exception:
                self._show_txt_tab()
                self._status("TXT показан во вкладке «Текст чата».", "ok")
        else:
            messagebox.showwarning("Архиватор", "Файл TXT не найден.")

    def open_data_folder(self):
        try:
            os.startfile(DATA_DIR)
        except Exception:
            try:
                webbrowser.open("file:///" + DATA_DIR.replace("\\", "/"))
            except Exception:
                self._status("Не удалось открыть папку data.", "err")

    def export_all(self):
        out = filedialog.asksaveasfilename(defaultextension=".zip",
                                           initialfile="genspark_archive.zip",
                                           filetypes=[("ZIP", "*.zip")])
        if not out:
            return
        try:
            base = out[:-4] if out.lower().endswith(".zip") else out
            shutil = __import__("shutil")
            shutil.make_archive(base, "zip", DATA_DIR)
            messagebox.showinfo("Экспорт", "Архив сохранён: %s" % (base + ".zip"))
        except Exception as e:
            messagebox.showerror("Экспорт", "Ошибка: %s" % e)

    def export_md(self):
        cid = self._sel()
        if not cid:
            messagebox.showinfo("Архиватор", "Выберите чат слева.")
            return
        ch = db.get_chat(cid)
        if not ch:
            return
        out = filedialog.asksaveasfilename(defaultextension=".md",
                                           initialfile=(ch.get("title") or "chat")[:60] + ".md",
                                           filetypes=[("Markdown", "*.md")])
        if not out:
            return
        try:
            data = _export_chat_to_markdown(cid)
            with open(out, "w", encoding="utf-8") as f:
                f.write(data)
            messagebox.showinfo("Экспорт в Markdown", "Готово: %s" % out)
        except Exception as e:
            messagebox.showerror("Экспорт", "Ошибка: %s" % e)

    def find_duplicates(self):
        chats = db.list_chats()
        if len(chats) < 2:
            messagebox.showinfo("Дубликаты", "В архиве меньше двух чатов.")
            return
        try:
            pairs = dupmod.find_duplicates(chats)
        except Exception as e:
            messagebox.showerror("Дубликаты", "Ошибка поиска: %s" % e)
            return
        win = tk.Toplevel(self.root)
        win.title("Дубликаты и похожие чаты")
        win.geometry("920x560")
        win.configure(bg=self.colors["bg"])
        cols = ("a", "b", "sim")
        tv = ttk.Treeview(win, columns=cols, show="headings")
        tv.heading("a", text="Чат A")
        tv.heading("b", text="Чат B")
        tv.heading("sim", text="Сходство")
        for a, b, sim in pairs or []:
            tv.insert("", "end", values=(a.get("title") or "", b.get("title") or "", sim))
        tv.pack(fill="both", expand=True, padx=8, pady=8)
        info = "Найдено пар: %d" % len(pairs) if pairs else "Дубликатов и похожих чатов не найдено."
        tk.Label(win, text=info, bg=self.colors["bg"], fg=self.colors["fg"],
                 font=self.colors["font"]).pack()

    # ---------------- объединённый поиск ----------------
    def on_search(self):
        q = self.search_var.get().strip()
        if not q:
            self.on_search_reset()
            return
        self._do_search(q, mode=self.search_mode_var.get())

    def on_semantic_search(self):
        q = self.search_var.get().strip()
        if not q:
            return
        self._do_search(q, mode="по смыслу")

    def _do_search(self, q, mode):
        chats = db.list_chats(sort_by=SORTS.get(self.sort_var.get(), "session"))
        if not chats:
            self._status("В архиве пока нет чатов.", "idle")
            return
        self._status("Ищу «%s» по %d чатам (режим: %s)…" % (q[:50], len(chats), mode), "work")
        mod = SEARCH_MODES.get(mode, "mixed")
        if mod == "mixed":
            target = searchmod.search(q, chats, limit=20,
                                      min_score=int(self.settings.get("min_score", 12)))
            info = "Найдено (слова+смысл): %d" % len(target)
        elif mod == "semantic":
            try:
                target = searchmod.semantic_search(q, chats, limit=20,
                                                  min_score=int(self.settings.get("min_score", 12)))
            except Exception:
                target = []
            info = "Найдено (по смыслу): %d" % len(target)
        else:
            # только слова — фоллбэк на search_chats
            try:
                target = searchmod.search_chats(q, chats, limit=20)
            except Exception:
                target = []
            info = "Найдено (по словам): %d" % len(target)
        self.search_highlight = q
        self._render_search_results(target, info)

    def _render_search_results(self, results, info_text):
        self.in_search = True
        self.search_map.clear()
        try:
            self.tree.delete(*self.tree.get_children())
        except Exception:
            pass
        for row in results:
            # результат может быть 4- или 5-кортежным
            if len(row) >= 5:
                ch, score, snippet, label, breakdown = row
            else:
                ch, score, snippet, label = row
                breakdown = None
            where_extra = ""
            if breakdown:
                where_extra = " [title=%s desc=%s body=%s смысл=%s]" % (
                    breakdown["title"], breakdown["desc"], breakdown["body"],
                    breakdown["semantic"])
            self._insert_row(ch, status_text="🔎 %d%% • %s%s" % (score, label, where_extra))
            self.search_map[ch["chat_id"]] = (ch, snippet)
        self.search_info.set(info_text)
        self._status(info_text + ". Жёлтым в TXT подсветятся совпадения.", "ok")
        if results:
            try:
                first = results[0][0]["chat_id"]
                self.tree.selection_set(first)
                self.tree.see(first)
            except Exception:
                pass

    def on_search_reset(self):
        self.search_var.set("")
        self.search_info.set("")
        self.search_highlight = ""
        self.refresh_list()

    # ---------------- мои промпты ----------------
    def _refresh_prompts_list(self):
        q = self.prompt_q.get().strip().lower()
        try:
            items = promptsm.list_prompts()
        except Exception:
            items = []
        try:
            self.prom_tree.delete(*self.prom_tree.get_children())
        except Exception:
            pass
        for p in items:
            text = p.get("text") or ""
            if q and q not in text.lower():
                continue
            chat_title = ""
            cid = p.get("chat_id") or ""
            if cid:
                chat = db.get_chat(cid)
                if chat:
                    chat_title = (chat.get("title") or "")[:24]
            vals = (p.get("created_at") or "", chat_title,
                    p.get("use_count") or 0, text[:240])
            try:
                self.prom_tree.insert("", "end", iid=str(p["id"]), values=vals)
            except Exception:
                pass

    def _save_current_as_prompt(self):
        text = self.prompt_q.get().strip()
        if not text:
            messagebox.showinfo("Мои промпты", "Введите текст промпта в поле.")
            return
        cid = self._sel() or ""
        promptsm.add_prompt(text, chat_id=cid, tags="")
        self._refresh_prompts_list()
        self._status("Промпт сохранён.", "ok")

    def _use_prompt(self, _evt=None):
        sel = self.prom_tree.selection()
        if not sel:
            return
        items = promptsm.list_prompts()
        try:
            pid = int(sel[0])
        except Exception:
            return
        cur = next((x for x in items if x.get("id") == pid), None)
        if not cur:
            return
        try:
            promptsm.bump_use(pid)
        except Exception:
            pass
        text = cur.get("text") or ""
        # ищем по целому промпту (а не по обрывку)
        self.url_var.set("")
        self.search_var.set(text)
        self.on_search()
        self._refresh_prompts_list()
        self._status("Ищу чаты по промпту: «%s…»" % text[:60], "ok")

    def _delete_prompt(self):
        sel = self.prom_tree.selection()
        if not sel:
            return
        try:
            pid = int(sel[0])
        except Exception:
            return
        try:
            promptsm.delete_prompt(pid)
        except Exception:
            pass
        self._refresh_prompts_list()

    # ---------------- выгрузка ----------------
    def on_go(self):
        url = self.url_var.get().strip()
        if not url:
            messagebox.showinfo("Архиватор", "Вставьте ссылку на чат.")
            return
        if "genspark.ai" not in url.lower() and not messagebox.askyesno(
                "Архиватор", "Ссылка не похожа на Genspark. Всё равно попробовать?"):
            return
        self._save_settings()
        cid = extractor.chat_id_from(url)
        if cid in self.loading_ids:
            self._status("Эта ссылка уже выгружается…", "work")
            return
        self.loading_ids.add(cid)
        self._insert_row({"chat_id": cid, "title": "(выгружается…) " + url[:60],
                          "first_prompt_at": "", "txt_path": "", "favorite": 0})
        try:
            self.tree.see(cid)
        except Exception:
            pass
        self._set_light("work")
        self.progress.pack(fill="x", padx=10, pady=(0, 4))
        self.progress.start(14)
        self.go_btn.configure(state="disabled")
        threading.Thread(target=self._work, args=(url, cid), daemon=True).start()

    def _work(self, url, cid):
        try:
            driver = None
            try:
                driver = extractor.create_driver(
                    headless=self.headless_var.get(),
                    status=lambda m: self.q.put(("status", (m, "work"))))
                data = extractor.extract_chat(
                    driver, url, status=lambda m: self.q.put(("status", (m, "work"))))
            finally:
                if driver:
                    try:
                        driver.quit()
                    except Exception:
                        pass
            self.q.put(("status", ("Сохраняю текст и строю описания (БЕЗ ИИ — sumy)…", "work")))
            txt_path = db.save_artifacts(cid, data)
            # 7) описания — через sumy, без ИИ (offline режим)
            if HAVE_SUMY and summod is not None:
                smin, smed, smax = summod.make_descriptions(data["text"], data["title"])
                descs = {"min": self._wrap_desc("минимальное", data["title"], smin, "sumy (TextRank/LexRank)"),
                         "med": self._wrap_desc("среднее", data["title"], smed, "sumy (TextRank/LexRank)"),
                         "max": self._wrap_desc("максимальное", data["title"], smax, "sumy (TextRank/LexRank)")}
            elif summod is not None:
                descs = summod.make_all_descriptions(data["text"], data["title"])
            else:
                descs = {"min": "(нет модуля описаний)", "med": "(нет модуля описаний)",
                         "max": "(нет модуля описаний)"}
            db.upsert_chat(cid, data["url"], data["title"], data["first_prompt_at"],
                           txt_path, descs, self.engine_var.get())
            self.q.put(("ok", (cid, data["title"])))
        except Exception as e:
            self.q.put(("fail", (cid, str(e))))

    @staticmethod
    def _wrap_desc(kind, title, body, engine):
        head = "Описание чата: %s\nРежим: %s | Движок: %s" % (
            (title or "").strip(), kind, engine)
        return head + "\n\n" + (body or "(пусто)")

    def _drain_queue(self):
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "status":
                    msg, level = payload
                    self._status(msg, level)
                elif kind == "ok":
                    cid, title = payload
                    self.loading_ids.discard(cid)
                    try:
                        self.progress.stop()
                        self.progress.pack_forget()
                    except Exception:
                        pass
                    self.go_btn.configure(state="normal")
                    self._set_light("ok")
                    self._status("Готово: «%s» — TXT лежит рядом, строка позеленела." % title, "ok")
                    if self.in_search:
                        self.on_search()
                    else:
                        self.refresh_list(select_id=cid)
                    try:
                        self.url_entry.delete(0, "end")
                    except Exception:
                        pass
                elif kind == "fail":
                    cid, err = payload
                    self.loading_ids.discard(cid)
                    try:
                        self.progress.stop()
                        self.progress.pack_forget()
                    except Exception:
                        pass
                    self.go_btn.configure(state="normal")
                    self._set_light("err")
                    self.refresh_list()
                    messagebox.showerror("Ошибка выгрузки", err)
        except queue.Empty:
            pass
        try:
            self.root.after(200, self._drain_queue)
        except Exception:
            pass

    def _set_light(self, state):
        color = {"idle": "#9a9a9a", "work": "#e6b800", "ok": "#35b23a", "err": "#d64545"}.get(state, "#9a9a9a")
        try:
            self.light.configure(bg=color)
        except Exception:
            pass

    def _status(self, msg, level="idle"):
        self.status_var.set(msg)
        if level == "work":
            self._set_light("work")
        elif level == "ok":
            self._set_light("ok")

    def _save_settings(self):
        self.settings.update({
            "engine": self.engine_var.get(),
            "gemini_key": self.key_var.get().strip(),
            "headless": bool(self.headless_var.get()),
            "theme": self.theme_var.get(),
            "search_mode": self.search_mode_var.get(),
        })
        save_settings(self.settings)
        self._status("Настройки сохранены.", "ok")

    def _change_theme(self):
        self._save_settings()
        try:
            self.colors = thememod.apply_theme(self.root, self.theme_var.get())
        except Exception:
            pass
        self._apply_row_tags()
        self._status("Тема «%s» применена." % self.theme_var.get(), "ok")

    def _on_close(self):
        try:
            self.save_notes()
        except Exception:
            pass
        try:
            self.root.destroy()
        except Exception:
            pass


# ---------------- markdown экспорт ----------------
def _export_chat_to_markdown(chat_id):
    ch = db.get_chat(chat_id)
    if not ch:
        return ""
    txt_path = ch.get("txt_path") or ""
    body = ""
    if txt_path and os.path.exists(txt_path):
        with open(txt_path, encoding="utf-8", errors="ignore") as f:
            body = f.read()
    lines = [
        "# %s" % (ch.get("title") or "Без названия"),
        "",
        "- **Ссылка:** %s" % ch.get("url"),
        "- **ID чата:** `%s`" % chat_id,
        "- **Начало сессии:** %s" % (ch.get("first_prompt_at") or "—"),
        "- **Выгружено:** %s" % (ch.get("last_opened_at") or ""),
        "",
        "## Описание (минимум)",
        (ch.get("desc_min") or "").split("\n\n")[-1] if ch.get("desc_min") else "",
        "",
        "## Описание (среднее)",
        (ch.get("desc_med") or "").split("\n\n")[-1] if ch.get("desc_med") else "",
        "",
        "## Описание (максимальное)",
        (ch.get("desc_max") or "").split("\n\n")[-1] if ch.get("desc_max") else "",
        "",
        "## Полный текст чата",
        "```text",
        body,
        "```",
        "",
        "## Мои заметки",
        ch.get("notes") or "(пусто)",
        "",
    ]
    return "\n".join(lines)


# ---------------- демо-наполнение ----------------
def seed_demo():
    samples = [
        ("demo-aaaa-1111", "Создание архиватора чатов",
         "Пользователь попросил программу для выгрузки чатов Genspark в txt. "
         "Агент предложил Selenium без логина и без Playwright. Инструмент раскрыл "
         "свёрнутые блоки с агентами и размышлениями. Результат: весь текст сохраняется "
         "в файл рядом с программой. Описания теперь строятся офлайн через sumy (TextRank). "
         "Пользователь доволен и просит добавить избранное и заметки. " * 8),
        ("demo-bbbb-2222", "Разбор ошибок Python и драйвера Chrome",
         "В чате разбирали, почему ChromeDriver падал с ошибкой session not created. "
         "Агент объяснил про несовместимость версий браузера и драйвера. "
         "Инструменты: проверка версии, установка Selenium Manager. "
         "Размышления агента о совместимости. Итог: драйвер скачивается автоматически. " * 8),
        ("demo-cccc-3333", "Идеи интерфейса: кубики и зелёные статусы",
         "Пользователь хочет интерфейс с кубиками и цветными статусами. "
         "Агент предложил темы оформления и теги строк. Обсуждали поиск с опечатками "
         "по всему архиву на бесплатной библиотеке RapidFuzz с GitHub, а также семантику "
         "на TF-IDF + словаре синонимов — всё офлайн. " * 8),
    ]
    db.init_db()
    for i, (cid, title, text) in enumerate(samples):
        day = (datetime.datetime.now() - datetime.timedelta(days=i * 3)).strftime("%Y-%m-%d %H:%M:%S")
        data = {"title": title, "url": "https://www.genspark.ai/agents?id=" + cid,
                "first_prompt_at": day, "text": text, "html": ""}
        txt_path = db.save_artifacts(cid, data)
        if HAVE_SUMY and summod is not None:
            smin, smed, smax = summod.make_descriptions(text, title)
            descs = {"min": "Описание чата: %s\nРежим: минимальное | Движок: sumy (TextRank/LexRank)\n\n%s"
                     % (title, smin),
                     "med": "Описание чата: %s\nРежим: среднее | Движок: sumy (TextRank/LexRank)\n\n%s"
                     % (title, smed),
                     "max": "Описание чата: %s\nРежим: максимальное | Движок: sumy (TextRank/LexRank)\n\n%s"
                     % (title, smax)}
        else:
            descs = {"min": text[:400], "med": text[:800], "max": text[:1200]}
        db.upsert_chat(cid, data["url"], title, day, txt_path, descs, "offline")
    db.set_favorite("demo-bbbb-2222", True)
    db.update_notes("demo-aaaa-1111",
                    "ВАЖНО: первый чат про архиватор.\nЗдесь обсуждали Selenium, статусы и офлайн-описания (sumy).")
    try:
        promptsm.add_prompt("Как выгрузить чаты Genspark в txt?", "demo-aaaa-1111", "")
        promptsm.add_prompt("Почему падает ChromeDriver session not created?", "demo-bbbb-2222", "")
        promptsm.add_prompt("Хочу интерфейс с кубиками и зелёными статусами", "demo-cccc-3333", "")
    except Exception:
        pass


def main():
    if "--demo" in sys.argv:
        seed_demo()
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
