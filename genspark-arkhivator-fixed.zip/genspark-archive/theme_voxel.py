# -*- coding: utf-8 -*-
"""Voxel-блоковая палитра и стили для Tkinter/ttk.

Не копирует Minecraft и чужой брендинг. Используем ОТКРЫТЫЕ палитры:
основные цвета - изумрудный, мох, песок, сланец, тёплое дерево;
дополнительные - broken voxel accents.

Пользовательский шрифт: пытается загрузить Press Start 2P (SIL Open Font,
google/fonts, OFL) или любой пиксельный моноширныйный, что установлены.
Если ничего нет - используется системный моноширныйный. Это безопасно.
"""
THEMES = {
    "Светлая": {
        "bg":        "#f3ecd2",   # песок
        "panel":     "#d9c896",   # светлое дерево
        "panel_dk":  "#b89c5b",   # тёмное дерево
        "frame":     "#9a7b3f",   # контур
        "accent":    "#3f8b3f",   # мох (кнопки)
        "accent_dk": "#265c26",   # тёмный мох
        "emerald":   "#2e8b57",   # изумруд
        "slate":     "#5a6266",   # сланец
        "fg":        "#2a2118",   # почти чёрный
        "shadow":    "#7b6a3a",
        "entry_bg":  "#fbf6df",
        "entry_fg":  "#2a2118",
        "tree_bg":   "#ede1b6",
        "tree_fg":   "#2a2118",
        "tree_sel":  "#9bd29b",
        "select":    "#9bd29b",
        "hit":       "#e9d84a",   # подсветка найденных слов
        "warn":      "#a55a2a",
        "ok":        "#2e8b57",
        "err":       "#a83232",
        "working":   "#cba31a",
    },
    "Тёмная": {
        "bg":        "#2b2f25",
        "panel":     "#3d4433",
        "panel_dk":  "#2a3022",
        "frame":     "#1a1d12",
        "accent":    "#5fb264",
        "accent_dk": "#2f7a3c",
        "emerald":   "#7ad48a",
        "slate":     "#888e91",
        "fg":        "#ece6c8",
        "shadow":    "#10130a",
        "entry_bg":  "#1f2418",
        "entry_fg":  "#ece6c8",
        "tree_bg":   "#383c30",
        "tree_fg":   "#ece6c8",
        "tree_sel":  "#5a8a4a",
        "select":    "#5a8a4a",
        "hit":       "#ffe14a",
        "warn":      "#e09c3a",
        "ok":        "#7ad48a",
        "err":       "#e07c7c",
        "working":   "#e5c14a",
    },
    "Высокий контраст": {
        "bg":        "#1c1f15",
        "panel":     "#262b1d",
        "panel_dk":  "#10130a",
        "frame":     "#000000",
        "accent":    "#ffe14a",
        "accent_dk": "#a89a20",
        "emerald":   "#5fff8a",
        "slate":     "#c0c4c8",
        "fg":        "#ffffff",
        "shadow":    "#000000",
        "entry_bg":  "#000000",
        "entry_fg":  "#ffe14a",
        "tree_bg":   "#10130a",
        "tree_fg":   "#ffffff",
        "tree_sel":  "#ffe14a",
        "select":    "#ffe14a",
        "hit":       "#ff4444",
        "warn":      "#ffaa55",
        "ok":        "#55ff55",
        "err":       "#ff5555",
        "working":   "#ffee55",
    },
}

VOXEL_FONT_FAMILY_CANDIDATES = [
    "Press Start 2P",
    "Pixelify Sans",
    "Silkscreen",
    "VT323",
    "Courier New",
    "Consolas",
    "Menlo",
    "Monaco",
    "DejaVu Sans Mono",
    "monospace",
]


def _detect_pixel_font():
    """Возвращает имя шрифта, доступного в системе. Без handler - без падений."""
    try:
        from tkinter import font as tkfont
        families = set(tkfont.families())
        for f in VOXEL_FONT_FAMILY_CANDIDATES:
            if f in families:
                return f
        return "TkDefaultFont"
    except Exception:
        return "TkDefaultFont"


_PIXEL_FONT_NAME = {"name": None}


def pixel_font(size=10, bold=False):
    if _PIXEL_FONT_NAME["name"] is None:
        _PIXEL_FONT_NAME["name"] = _detect_pixel_font()
    name = _PIXEL_FONT_NAME["name"]
    f = (name, size, "bold" if bold else "normal")
    return f


def list_themes():
    return list(THEMES.keys())


VOXEL_BORDER = {
    # имитация stepped pixel-edge через tk.RELIEF + дополнительный рельеф
    "padding_x": 6,
    "padding_y": 4,
    "btn_padx": 10,
    "btn_pady": 5,
}


def apply_theme(root, name):
    t = THEMES.get(name) or THEMES["Светлая"]
    try:
        from tkinter import ttk
        s = ttk.Style(root)
        s.theme_use("clam")
        base = ("TkDefaultFont", 10)
        s.configure(".", background=t["bg"], foreground=t["fg"], font=base)
        s.configure("TFrame", background=t["bg"])
        s.configure("Panel.TFrame", background=t["panel"], relief="ridge", borderwidth=3)
        s.configure("Stone.TFrame", background=t["panel"], relief="groove", borderwidth=2)
        s.configure("TLabel", background=t["bg"], foreground=t["fg"], font=base)
        s.configure("Panel.TLabel", background=t["panel"], foreground=t["fg"], font=base)
        s.configure("Stone.TLabel", background=t["panel_dk"], foreground=t["fg"], font=base)
        s.configure("Big.TLabel", background=t["bg"], foreground=t["emerald"], font=("TkDefaultFont", 12, "bold"))
        s.configure("TButton", background=t["panel"], foreground=t["fg"],
                    font=("TkDefaultFont", 10, "bold"), padding=(VOXEL_BORDER["btn_padx"],
                                                                VOXEL_BORDER["btn_pady"]),
                    relief="raised", borderwidth=3)
        s.map("TButton",
              background=[("active", t["accent"]), ("disabled", t["panel_dk"])],
              foreground=[("disabled", t["shadow"])])
        s.configure("Accent.TButton", background=t["accent"], foreground="#ffffff",
                    font=("TkDefaultFont", 10, "bold"),
                    padding=(VOXEL_BORDER["btn_padx"], VOXEL_BORDER["btn_pady"]))
        s.map("Accent.TButton", background=[("active", t["accent_dk"])])
        s.configure("Danger.TButton", background=t["panel"], foreground=t["err"],
                    font=("TkDefaultFont", 10, "bold"))
        s.configure("TEntry", fieldbackground=t["entry_bg"], foreground=t["entry_fg"],
                    insertcolor=t["fg"], borderwidth=2, relief="sunken")
        s.configure("TCombobox", fieldbackground=t["entry_bg"], foreground=t["entry_fg"],
                    borderwidth=2)
        s.configure("Treeview", background=t["tree_bg"], foreground=t["tree_fg"],
                    fieldbackground=t["tree_bg"], rowheight=26,
                    borderwidth=2, relief="ridge")
        s.map("Treeview", background=[("selected", t["select"])],
              foreground=[("selected", t["fg"])])
        s.configure("Treeview.Heading", background=t["panel_dk"], foreground=t["fg"],
                    font=("TkDefaultFont", 10, "bold"), relief="raised")
        s.configure("TRadiobutton", background=t["bg"], foreground=t["fg"])
        s.configure("TCheckbutton", background=t["bg"], foreground=t["fg"])
        s.configure("TNotebook", background=t["frame"], borderwidth=3, relief="ridge")
        s.configure("TNotebook.Tab", background=t["panel"], foreground=t["fg"],
                    font=("TkDefaultFont", 10, "bold"), padding=(14, 6))
        s.map("TNotebook.Tab",
              background=[("selected", t["accent"])],
              foreground=[("selected", "#ffffff")])
        s.configure("Accent.Horizontal.TScrollbar", background=t["accent"],
                    troughcolor=t["panel"], borderwidth=2, relief="raised")
        s.configure("Stone.Horizontal.TProgressbar",
                    background=t["accent"], troughcolor=t["panel_dk"], borderwidth=2)
    except Exception:
        pass
    try:
        root.configure(bg=t["bg"])
    except Exception:
        pass
    return t


# Безопасный lookup - в любом месте кода можно theme.t("bg") вместо theme.t["bg"]["bg"]
class TProxy(dict):
    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError:
            return None


def tdict(t):
    return TProxy(t)
