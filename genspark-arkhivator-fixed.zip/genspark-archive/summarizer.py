# -*- coding: utf-8 -*-
"""Совместимая обёртка — старый импорт `summarizer.make_all_descriptions(...)` продолжает работать."""
from sumy_summarizer import make_descriptions, build_stats, describe_mode_label, HAVE_SUMY  # noqa


TARGETS = {"min": 2, "med": 5, "max": 8}
NAMES = {"min": "минимальное (10-15)", "med": "среднее (40-50)", "max": "максимальное (70+)"}
ALL = ("min", "med", "max")


def make_all_descriptions(text, title=""):
    smin, smed, smax = make_descriptions(text, title)
    return {"min": smin, "med": smed, "max": smax}
