# -*- coding: utf-8 -*-
"""Описания чата в трёх режимах — полностью БЕЗ ИИ.

Используется библиотека sumy (https://github.com/miso-belica/sumy, Apache-2.0):
extractive-алгоритмы TextRank и LexRank. Русский поддерживается штатно.

Если sumy недоступна — включается fallback на собственный TF-IDF
с сигнальными словами (как было в исходной программе).
"""
import re
from collections import Counter


# ---------- fallback ----------
STOP = set((
    "и в во не что он на я с со как а то все она так его но да ты к у же вы за бы по "
    "только ее мне было вот от меня еще нет о из ему теперь когда даже ну вдруг ли "
    "если уже или ни быть был него до вас уж это их при сам себе чем об этом этот "
    "свои обо между где самый также потом чтобы для поэтому затем поскольку хотя более "
    "менее очень совсем почти около через кроме среди значит например однако равно же "
    "the a an and or of to in is it for on with as by at from this that these those "
    "be been being was were are will would can could should may might not no yes so "
    "but if then than too very just also only even here there when where how what who "
    "whom which while during after before about above below over under again further "
    "once more most such some any all each few both neither nor own same other another"
).split())

SIGNAL = (
    "агент", "инструмент", "размышл", "промпт", "задач", "ответ", "результат",
    "итог", "вывод", "код", "файл", "данн", "бд", "gemini", "selenium",
    "браузер", "скрипт", "программ", "ошибк", "работа", "сделать", "использ",
    "функц", "алгоритм", "реализ", "провер", "проект", "python", "решение",
    "шаг", "этап", "план", "создан", "получ", "запрос", "диалог", "сообщен",
    "ссылка", "страниц", "чат",
)

_SENT = re.compile(r"(?<=[.!?…])\s+(?=[А-ЯЁA-Z0-9«\"(\[])")
_WORD = re.compile(r"[A-Za-zА-Яа-яЁё0-9]+")


def _split(text):
    text = re.sub(r"\s+", " ", (text or "")).strip()
    if not text:
        return []
    return [p.strip() for p in _SENT.split(text)
            if p.strip() and len(p.strip()) > 12]


def _fallback(text):
    sents = _split(text)
    if not sents:
        return ("(пусто)", "(пусто)", "(пусто)")
    freq = Counter()
    for s in sents:
        for w in _WORD.findall(s.lower()):
            if w not in STOP:
                freq[w] += 1
    maxf = max(freq.values()) if freq else 1
    total = max(1, len(sents))
    scored = []
    for i, s in enumerate(sents):
        ws = [w for w in _WORD.findall(s.lower()) if w not in STOP]
        tf = (sum(freq.get(w, 0) for w in ws) / maxf) if ws else 0.0
        rel = i / total
        if rel <= 0.05:
            pos = 1.0
        elif rel <= 0.2:
            pos = 0.8
        elif rel <= 0.6:
            pos = 0.5
        else:
            pos = 0.3
        sig = sum(1 for w in ws if any(x in w for x in SIGNAL)) / max(1, len(ws))
        ln = min(len(ws), 40) / 40.0
        scored.append((0.45 * tf + 0.20 * pos + 0.25 * sig + 0.10 * ln, i, s))

    def take(n):
        seen, used = [], set()
        for _, i, s in sorted(scored, key=lambda x: -x[0]):
            ws = set(_WORD.findall(s.lower()))
            if not ws or len(ws & used) / max(1, len(ws | used)) > 0.55:
                continue
            seen.append(s)
            used |= ws
            if len(seen) >= n:
                break
        if len(seen) < n:
            for _, i, s in scored:
                if s not in seen:
                    seen.append(s)
                    if len(seen) >= n:
                        break
        return " ".join(seen[:n])

    return (take(2), take(5), take(8))


# ---------- основной путь через sumy ----------
# Реальные имена модулей в sumy 0.13.
try:
    from sumy.parsers.plaintext import PlaintextParser
    from sumy.nlp.tokenizers import Tokenizer
    from sumy.summarizers.text_rank import TextRankSummarizer
    from sumy.summarizers.lex_rank import LexRankSummarizer
    HAVE_SUMY = True
except Exception:
    HAVE_SUMY = False


def _sumy(text, n):
    if not HAVE_SUMY or not text or not text.strip():
        return None
    try:
        parser = PlaintextParser.from_string(text, Tokenizer("russian"))
    except Exception:
        return None
    try:
        out = " ".join(
            str(s) for s in TextRankSummarizer()(parser.document, n)
        ).strip()
        if out:
            return out
    except Exception:
        pass
    try:
        out = " ".join(
            str(s) for s in LexRankSummarizer()(parser.document, n)
        ).strip()
        return out or None
    except Exception:
        return None


def make_descriptions(text, title=""):
    """Возвращает (мин, среднее, макс) описания чата строкой."""
    base = (text or "").strip()
    if not base:
        return ("", "", "")
    a_ = _sumy(base, 2) or _fallback(base)[0]
    b_ = _sumy(base, 5) or _fallback(base)[1]
    c_ = _sumy(base, 8) or _fallback(base)[2]
    return (a_, b_, c_)


def build_stats(text):
    low = (text or "").lower()
    return (
        "Статистика: символов ~%d, упомин. агентов ~%d, "
        "инструментов ~%d, размышлений ~%d"
        % (len(text or ""),
           low.count("агент") + low.count("agent"),
           low.count("инструмент") + low.count("tool"),
           low.count("размышл") + low.count("thinking"))
    )


def describe_mode_label(mode):
    return {
        "offline": "Офлайн (sumy: TextRank/LexRank)",
        "gemini":  "Через Gemini API",
    }.get(mode, mode or "offline")
