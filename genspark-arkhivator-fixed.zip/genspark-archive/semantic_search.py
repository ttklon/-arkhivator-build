# -*- coding: utf-8 -*-
"""Обёртка над unified_search для совместимости со старым gui."""
from unified_search import semantic_search  # noqa
from unified_search import TfIdfIndex  # noqa
