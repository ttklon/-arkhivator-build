# -*- coding: utf-8 -*-
"""Обёртка над unified_search для совместимости со старым gui."""
from unified_search import search as _search  # noqa
from unified_search import search_chats  # noqa
