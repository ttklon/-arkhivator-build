chcp 866 >nul
@echo off
setlocal
cd /d "%~dp0"
title Genspark Arkhivator
where python >nul 2>nul
if errorlevel 1 (
  echo [OSHIBKA] Python 3.10+ ne najden. Skachayte s python.org i VKLYUCHITE "Add Python to PATH".
  pause
  exit /b 1
)
python -c "import selenium, requests, rapidfuzz, sumy" >nul 2>nul
if errorlevel 1 (
  echo Pervyj zapusk: stavlyu biblioteki...
  python -m pip install --upgrade pip
  python -m pip install -r requirements.txt
  if errorlevel 1 (
    echo Biblioteki ne ustanovleni. Proverte internet.
    pause
    exit /b 1
  )
)
python gui.py %*
if errorlevel 1 (
  echo Oshibka zapuska programmy. Nuzhen Python 3.10+.
  pause
)
