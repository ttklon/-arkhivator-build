# -*- coding: utf-8 -*-
"""Единый движок поиска по архиву: keyword + fuzzy (RapidFuzz) +
ТF-IDF + словарь синонимов (без sentence-transformers, без интернета).
Принимает список чатов и запрос — возвращает чаты с баллом и местом
совпадения ("в названии"/"в описании"/"в тексте чата"/"семантика").

Объединяет search.py и semantic_search.py в одну точку входа.
"""
import math
import os
import re
from collections import Counter

try:
    from rapidfuzz import fuzz
    HAVE_RF = True
except Exception:
    HAVE_RF = False
    from difflib import SequenceMatcher

_WORD = re.compile(r"[A-Za-zА-Яа-яЁё0-9]+")

# Расширенный русскоязычный словарь синонимов и опечаток
SYNONYMS = {
    "ошибк": ["баг", "краш", "сбой", "fail", "error", "exception", "traceback"],
    "браузер": ["хром", "chrome", "edge", "selenium", "драйвер", "chromedriver"],
    "выгрузить": ["скачать", "сохранить", "экспорт", "extract", "dump", "загрузить"],
    "описани": ["summary", "пересказ", "аннотац", "саммари", "кратк"],
    "поиск": ["search", "найти", "lookup", "искать", "наход"],
    "чат": ["диалог", "conversation", "агент", "сессия", "разговор"],
    "агент": ["помощник", "assistant", "исполнитель"],
    "файл": ["документ", "txt", "file", "архив"],
    "заметк": ["note", "запис", "коммент"],
    "статус": ["status", "состоян", "готов"],
    "кнопк": ["button", "нажм"],
    "тема": ["theme", "стиль", "оформлен", "дизайн"],
    "интерфейс": ["ui", "gui", "окно", "меню"],
    "selenium": ["браузер", "хром", "драйвер", "chromedriver"],
    "selenium": ["браузер", "хром", "драйвер"],
}


# ---------- утилиты токенизации ----------
def _norm(s):
    s = (s or "").lower().replace("ё", "е")
    return re.sub(r"\s+", " ", s).strip()


def _tokens(t):
    return _WORD.findall((t or "").lower())


def _expand(toks):
    out = list(toks)
    for t in toks:
        for k, syns in SYNONYMS.items():
            if k in t or t in k:
                out.extend(syns)
    return out


# ---------- семантический поиск: TF-IDF + синонимы ----------
class TfIdfIndex:
    def __init__(self, docs):
        # docs: dict[id] -> text
        self.docs = docs
        self.ids = list(docs.keys())
        self.N = max(1, len(self.ids))
        self._build()

    def _terms(self, text):
        return _expand(_tokens(text))

    def _build(self):
        self.tf = {}
        self.df = Counter()
        for cid, text in self.docs.items():
            terms = self._terms(text)
            c = Counter(terms)
            self.tf[cid] = c
            for w in c:
                self.df[w] += 1

    def vector(self, cid):
        tf = self.tf.get(cid, {})
        return {w: (c * math.log((self.N + 1) / (1 + self.df.get(w, 0))) + 1)
                for w, c in tf.items()}

    def query_vector(self, query):
        terms = self._terms(query)
        c = Counter(terms)
        return {w: (cnt * math.log((self.N + 1) / (1 + self.df.get(w, 0))) + 1)
                for w, cnt in c.items()}

    @staticmethod
    def _cos(a, b):
        if not a or not b:
            return 0.0
        num = sum(a.get(w, 0) * b.get(w, 0) for w in a.keys() & b.keys())
        den = math.sqrt(sum(v * v for v in a.values())) * math.sqrt(sum(v * v for v in b.values()))
        return (num / den) if den else 0.0

    def search(self, query):
        qv = self.query_vector(query)
        out = []
        for cid in self.ids:
            sim = self._cos(qv, self.vector(cid))
            out.append((cid, sim))
        return sorted(out, key=lambda x: -x[1])


# ---------- keyword + fuzzy (бывший search.py) ----------
def _sim(a, b):
    if not a or not b:
        return 0.0
    if HAVE_RF:
        return float(max(fuzz.partial_ratio(a, b), fuzz.token_set_ratio(a, b)))
    return 100.0 * SequenceMatcher(None, a, b).ratio()


def _fuzzy_score(query, text):
    a, b = _norm(query), _norm(text)
    if not a or not b:
        return 0.0
    if HAVE_RF:
        return float(fuzz.token_set_ratio(a, b))
    qw = _WORD.findall(a)
    words = _WORD.findall(b)
    if not qw or not words:
        return 0.0
    s_total = 0.0
    for q in qw:
        best = 0.0
        for w in words:
            if q == w or q in w or w in q:
                best = 100.0
                break
            r = SequenceMatcher(None, q, w).ratio() * 100.0
            if r > best:
                best = r
        s_total += best
    return s_total / max(1, len(qw))


def _read_txt(path, limit=600_000):
    try:
        if path and os.path.exists(path):
            with open(path, encoding="utf-8", errors="ignore") as f:
                return f.read(limit)
    except Exception:
        pass
    return ""


def _best_chunk(query, text, size=420, step=300):
    t = text or ""
    tn = _norm(t)
    if not tn:
        return 0.0, ""
    bs = 0.0
    bp = 0
    for pos in range(0, max(1, len(tn) - size + 1), step):
        s = _fuzzy_score(query, tn[pos:pos + size])
        if s > bs:
            bs, bp = s, pos
    snippet = re.sub(r"\s+", " ", t[bp:bp + size]).strip()
    return bs, snippet


# ---------- единая точка входа ----------
def search(query, chats, limit=20, min_score=15):
    """Возвращает список кортежей:
       (chat, score_0_100, snippet, where, breakdown_dict)
    """
    q = (query or "").strip()
    if not q:
        return []

    # 1) собираем корпуса для семантики
    docs = {}
    for ch in chats:
        cid = ch.get("chat_id") or ""
        corpus = " ".join([
            ch.get("title", "") or "",
            ch.get("desc_min", "") or "",
            ch.get("desc_med", "") or "",
        ])
        # добавим первые 30к символов текста чата
        body = _read_txt(ch.get("txt_path", ""))
        if body:
            corpus += " " + body[:30000]
        if corpus.strip():
            docs[cid] = corpus

    sem_scores = {}
    if len(docs) >= 2:
        try:
            idx = TfIdfIndex(docs)
            for cid, sim in idx.search(q):
                # косинус 0..1; превратим в проценты и масштабируем
                sem_scores[cid] = sim * 100.0
        except Exception:
            sem_scores = {}

    out = []
    for ch in chats:
        cid = ch.get("chat_id") or ""
        title = ch.get("title") or ""
        desc_all = " ".join([
            ch.get("desc_min", "") or "",
            ch.get("desc_med", "") or "",
            ch.get("desc_max", "") or "",
        ])[:30000]
        body = _read_txt(ch.get("txt_path"))

        title_s = _fuzzy_score(q, title)
        desc_s = _fuzzy_score(q, desc_all) if desc_all else 0.0
        body_s, snippet_body = _best_chunk(q, body) if body else (0.0, "")
        sem_s = sem_scores.get(cid, 0.0)

        # взвешенное объединение
        title_w = 1.05
        desc_w = 0.92
        body_w = 0.95
        sem_w = 0.90
        combined = max(
            title_s * title_w,
            desc_s * desc_w,
            body_s * body_w,
            sem_s * sem_w + (title_s + desc_s + body_s) * 0.05,
        )

        # выбираем "где нашлось"
        cands = [
            ("в названии", title_s * title_w,
             (title or "")[:300]),
            ("в описании", desc_s * desc_w,
             (ch.get("desc_min") or "")[:300] or (ch.get("desc_med") or "")[:300]),
            ("в тексте чата", body_s * body_w, snippet_body),
            ("семантика", sem_s * sem_w + (title_s + desc_s) * 0.02,
             snippet_body or (title or "")),
        ]
        cands.sort(key=lambda x: -x[1])
        where, where_score, snippet = cands[0]
        if not snippet:
            snippet = (title or "")[:300]

        if combined < 5:
            continue

        breakdown = {
            "title": round(title_s, 1),
            "desc": round(desc_s, 1),
            "body": round(body_s, 1),
            "semantic": round(sem_s, 1),
            "combined": round(combined, 1),
            "where": where,
        }

        # форматируем итоговый score 0..100 - клампим
        score = max(0, min(100, round(combined)))
        label = where if score >= min_score else where + " (слабое совпадение)"
        out.append((ch, score, snippet[:400], label, breakdown))

    out.sort(key=lambda x: -x[1])
    return out[:limit]


# Синонимы, чтобы старые вызовы из gui.py не сломались, если остались
search_chats = search


def semantic_search(query, chats, limit=20, min_score=15):
    """Обёртка, оставленная для совместимости с прежним кодом."""
    res = search(query, chats, limit=limit, min_score=min_score)
    return [(ch, score, snippet, label) for (ch, score, snippet, label, _) in res]
